const express = require('express');
const cors = require('cors');
const staticRoutes = require('./routes/static.routes');
const path = require("path");

const app = express();

app.use(express.json({ limit: '30mb', extended: true }));
app.use(express.urlencoded({ limit: '30mb', extended: true }));
app.use(cors());

app.use(express.static(path.join(__dirname,'static')));

app.use('/admin', staticRoutes);

app.listen(8000 , ( ) => {
    console.log('Serv service running on port 8000');
})