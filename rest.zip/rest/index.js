const express = require('express');
const cors = require('cors');
require('dotenv').config();
const userRoutes = require( './rest/routes/user.routes.js');
const professionRoutes = require( './rest/routes/profession.routes.js');
const genreRoutes = require( './rest/routes/genre.routes.js');
const awardRoutes = require( './rest/routes/award.routes.js');
const winnersRoutes = require( './rest/routes/awardwinners.routes.js');
const celebrityRoutes = require( './rest/routes/celebrity.routes.js');
const eventRoutes = require( './rest/routes/event.routes.js');
const movieRoutes = require( './rest/routes/movie.routes.js');
const roleRoutes = require( './rest/routes/moviecelebrity.routes.js');
const newsRoutes = require( './rest/routes/news.routes.js');
const reviewRoutes = require( './rest/routes/review.routes.js');
const { sequelize} = require('./models');

const app = express();

app.use(express.json({ limit: '30mb', extended: true }));
app.use(express.urlencoded({ limit: '30mb', extended: true }));
app.use(cors());


app.use('/users', userRoutes);
app.use('/awards', awardRoutes);
app.use('/winners', winnersRoutes);
app.use('/celebrities', celebrityRoutes);
app.use('/events', eventRoutes);
app.use('/genres', genreRoutes);
app.use('/movies', movieRoutes);
app.use('/roles', roleRoutes);
app.use('/news', newsRoutes);
app.use('/professions', professionRoutes);
app.use('/reviews', reviewRoutes);


app.listen(4000 , ( ) => {
    console.log('Rest service running on port 4000');
})