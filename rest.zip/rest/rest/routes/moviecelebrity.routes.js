const express= require ('express');
const {createRole, getRoles, updateRole, deleteRole} =require( '../controllers/moviecelebrity.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createRole);
router.get('/get', authenticate, getRoles);
router.put('/update', authenticateAdmin, updateRole);
router.delete('/delete', authenticateAdmin ,deleteRole);

module.exports = router;