const express= require ('express');
const {createCelebrity, getCelebrities, updateCelebrity, deleteCelebrity} =require( '../controllers/celebrity.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createCelebrity);
router.get('/get', authenticate, getCelebrities);
router.put('/update', authenticateAdmin, updateCelebrity);
router.delete('/delete', authenticateAdmin ,deleteCelebrity);

module.exports = router;