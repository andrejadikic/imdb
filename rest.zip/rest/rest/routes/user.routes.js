const express= require ('express');
const {getUsers, deleteUsers, updateUsers} =require( '../controllers/user.controller.js');
const {authenticateAdmin} = require('../../middleware/auth.middleware.js');

const router = express.Router();
//authenticateAdmin
router.get('/get', authenticateAdmin, getUsers);
router.delete('/delete', authenticateAdmin, deleteUsers);
router.put('/update', authenticateAdmin, updateUsers);

module.exports = router;