const express= require ('express');
const {createAward, getAwards, updateAward, deleteAward} =require( '../controllers/award.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createAward);
router.get('/get', authenticate, getAwards);
router.put('/update', authenticateAdmin, updateAward);
router.delete('/delete', authenticateAdmin ,deleteAward);

module.exports = router;