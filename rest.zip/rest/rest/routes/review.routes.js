const express= require ('express');
const {createReview, getReviews, updateReview, deleteReview} =require( '../controllers/review.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createReview);
router.get('/get', authenticate, getReviews);
router.put('/update', authenticateAdmin, updateReview);
router.delete('/delete', authenticateAdmin ,deleteReview);

module.exports = router;