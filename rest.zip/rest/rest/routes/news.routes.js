const express= require ('express');
const {createNews, getNews, updateNews, deleteNews} =require( '../controllers/news.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createNews);
router.get('/get', authenticate, getNews);
router.put('/update', authenticateAdmin, updateNews);
router.delete('/delete', authenticateAdmin, deleteNews);

module.exports = router;