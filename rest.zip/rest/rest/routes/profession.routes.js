const express= require ('express');
const {createProfession, getProfessions, updateProfession, deleteProfession, getAllCelebrityWithProfession} =require( '../controllers/profession.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createProfession);
router.get('/', authenticate, getProfessions);
router.get("/:id", authenticate, getAllCelebrityWithProfession);
router.put('/update', authenticateAdmin, updateProfession);
router.delete('/delete', authenticateAdmin ,deleteProfession);

module.exports = router;