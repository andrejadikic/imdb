const express= require ('express');
const {createWinner, getWinners, updateWinner, deleteWinner} =require( '../controllers/awardwinners.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createWinner);
router.get('/get', authenticate, getWinners);
router.put('/update', authenticateAdmin, updateWinner);
router.delete('/delete', authenticateAdmin ,deleteWinner);

module.exports = router;