const express= require ('express');
const {createMovie, getMovies, updateMovie, deleteMovie} =require( '../controllers/movie.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createMovie);
router.get('/get', authenticate, getMovies);
router.put('/update', authenticateAdmin, updateMovie);
router.delete('/delete', authenticateAdmin ,deleteMovie);

module.exports = router;