const express= require ('express');
const {createEvent, getEvents, updateEvent, deleteEvent} =require( '../controllers/event.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createEvent);
router.get('/get', authenticate, getEvents);
router.put('/update', authenticateAdmin, updateEvent);
router.delete('/delete', authenticateAdmin ,deleteEvent);

module.exports = router;