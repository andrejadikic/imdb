const express= require ('express');
const {createGenres, getGenres, updateGenres, deleteGenres} =require( '../controllers/genre.controller.js');
const {authenticate, authenticateAdmin } = require('../../middleware/auth.middleware.js');

const router = express.Router();


router.post('/create', authenticateAdmin, createGenres);
router.get('/get', authenticate, getGenres);
router.put('/update', authenticateAdmin, updateGenres);
router.delete('/delete', authenticateAdmin ,deleteGenres);

module.exports = router;