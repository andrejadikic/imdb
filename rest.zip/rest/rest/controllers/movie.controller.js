const {schemaMovie}  = require('../../common/joivalidate');
const { sequelize, Movie , Genre} = require('../../models');

const getMovies = async (req, res) => {
  try {
    res.status(200).json(await Movie.findAll({
      include: [{ model: Genre, as: 'genre' }]
    }))
  } catch (error) {
    res.status(403).json({ message: error.message });
  }
};

const updateMovie = async (req, res) => {
  try {
    const {id, title, genreName, imageUrl , description, rating } = req.body;

    const genre = await Genre.findOne({where:{name:genreName}});
    if(genre== null) throw new Error('Genre does not exists');
    const genreId = genre.id;

    const movie = { title, genreId ,description,rating,imageUrl};
    
    const validate = schemaMovie.validate(movie);
    if (validate.error) throw new Error( validate.error.details[0].message);
  
    await Movie.update(movie, { where: 
      {id}
    })
    .then(genre=>{
      res.status(200).json(genre);
    })
  } catch (error) {
    res.status(403).json({ message: error.message });
  }
};

const deleteMovie = async (req, res) => {
  try {
    const {id} = req.body;
    await Movie.destroy({
      where: {id}
    })
    .then(genre =>{
      res.status(200).json(genre);
    })
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

const createMovie = async (req, res) => {
  try {
    const {title, genreName, imageUrl , description, rating } = req.body;

    const genre = await Genre.findOne({where:{name:genreName}});
    if(genre== null) throw new Error('Genre does not exists');
    const genreId = genre.id;

    const movie = { title, genreId ,description,rating,imageUrl};
    
    const validate = schemaMovie.validate(movie);
    if (validate.error) throw new Error( validate.error.details[0].message);

    await Movie.create(movie).then( genre =>{
      res.status(200).json(genre);
    })
  } catch (error) {
    res.status(403).json({ message: error.message });
  }
};

exports.getMovies = getMovies;
exports.deleteMovie = deleteMovie;
exports.updateMovie = updateMovie;
exports.createMovie = createMovie;